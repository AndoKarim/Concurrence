#!/bin/bash
###############################################################
# Team 22
# Authors: Abdelkarim Andolerzak & Anasse Ghira & Nicolas Pepin
###############################################################
path=$(dirname $0)

$path/bin/run -e2 -t1 -p4 -m
